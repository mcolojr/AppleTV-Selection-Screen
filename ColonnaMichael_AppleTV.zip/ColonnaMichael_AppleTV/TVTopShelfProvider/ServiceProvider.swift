//
//  ServiceProvider.swift
//  TVTopShelfProvider
//
//  Created by Michael Colonna on 12/9/17.
//  Copyright © 2017 ColonnaJr. All rights reserved.
//

import Foundation
import TVServices

class ServiceProvider: NSObject, TVTopShelfProvider {
    
    override init() {
        super.init()
    }
    
    // MARK: - TVTopShelfProvider protocol
    
    var topShelfStyle: TVTopShelfContentStyle {
        // Return desired Top Shelf style.
        return .sectioned
    }
    
    var topShelfItems: [TVContentItem] {
        
        /// HORROR MOVIES SECTION
        // 1
        let horrorMoviesIdentifier = TVContentIdentifier(identifier:
            "Horror Movies", container: nil)!
        let horrorMoviesSection = TVContentItem(contentIdentifier:
            horrorMoviesIdentifier)!
        horrorMoviesSection.title = "Horror Movies"
        
        //Grab the predefined data set we created in the extension for our data struct
        let horrorMovieToDisplay =  TVTopShelfData.section1ItemsForSectionTopShelf
        
        //Create the array of TVContentItems. First up to do that we need a TVContentIdentifier. Don't forget, this needs to be unique across all past, present, and future objects for your top shelf. We're also being careful here to use guard and drop errors to let us know if anything goes wrong here.
        let horrorMoviesArray: [TVContentItem] = horrorMovieToDisplay.map
        {dataItem in guard let contentIdentifier = TVContentIdentifier(identifier: dataItem.identifier, container: nil) else{
            fatalError("Error creating content identifier")
            }
            //Next we can create the actual content item using the identifier
            guard let contentItem = TVContentItem(contentIdentifier: contentIdentifier) else {
                fatalError("Error creating content item")
            }
            
            //Once those are both done we can populate the content item using the data from our struct and then return it to the new contentArray. That will then get returned to the insetTopShelfItems and used for the top shelf.
            contentItem.title = dataItem.title
            contentItem.displayURL = dataItem.displayURL
            // contentItem.imageURL = dataItem.imageUrl
            contentItem.setImageURL(dataItem.imageUrl, forTraits: .screenScale1x)
            contentItem.imageShape = .poster
            
            return contentItem
        }//end map
        
        horrorMoviesSection.topShelfItems =  horrorMoviesArray
        
        /// ACTION MOVIES SECTION
        // 2
        let actionMoviesIdentifier = TVContentIdentifier(identifier:
            "Action Movies", container: nil)!
        let actionMoviesSection = TVContentItem(contentIdentifier:
            actionMoviesIdentifier)!
        actionMoviesSection.title = "Action Movies"
        
        //Grab the predefined data set we created in the extension for our data struct
        let actionMovieToDisplay =  TVTopShelfData.section2ItemsForSectionTopShelf
        
        //Create the array of TVContentItems. First up to do that we need a TVContentIdentifier. Don't forget, this needs to be unique across all past, present, and future objects for your top shelf. We're also being careful here to use guard and drop errors to let us know if anything goes wrong here.
        let actionMoviesArray: [TVContentItem] = actionMovieToDisplay.map
        {dataItem in guard let contentIdentifier = TVContentIdentifier(identifier: dataItem.identifier, container: nil) else{
            fatalError("Error creating content identifier")
            }
            //Next we can create the actual content item using the identifier
            guard let contentItem = TVContentItem(contentIdentifier: contentIdentifier) else {
                fatalError("Error creating content item")
            }
            
            //Once those are both done we can populate the content item using the data from our struct and then return it to the new contentArray. That will then get returned to the insetTopShelfItems and used for the top shelf.
            contentItem.title = dataItem.title
            contentItem.displayURL = dataItem.displayURL
            // contentItem.imageURL = dataItem.imageUrl
            contentItem.setImageURL(dataItem.imageUrl, forTraits: .screenScale1x)
            contentItem.imageShape = .poster
            
            return contentItem
        }//end map
        
        actionMoviesSection.topShelfItems =  actionMoviesArray
        
        /// COMEDY MOVIES SECTION
        // 3
        let comedyMoviesIdentifier = TVContentIdentifier(identifier:
            "Comedy Movies", container: nil)!
        let comedyMoviesSection = TVContentItem(contentIdentifier:
            comedyMoviesIdentifier)!
        comedyMoviesSection.title = "Comedy Movies"
        
        //Grab the predefined data set we created in the extension for our data struct
        let comedyMovieToDisplay =  TVTopShelfData.section3ItemsForSectionTopShelf
        
        //Create the array of TVContentItems. First up to do that we need a TVContentIdentifier. Don't forget, this needs to be unique across all past, present, and future objects for your top shelf. We're also being careful here to use guard and drop errors to let us know if anything goes wrong here.
        let comedyMoviesArray: [TVContentItem] = comedyMovieToDisplay.map
        {dataItem in guard let contentIdentifier = TVContentIdentifier(identifier: dataItem.identifier, container: nil) else{
            fatalError("Error creating content identifier")
            }
            //Next we can create the actual content item using the identifier
            guard let contentItem = TVContentItem(contentIdentifier: contentIdentifier) else {
                fatalError("Error creating content item")
            }
            
            //Once those are both done we can populate the content item using the data from our struct and then return it to the new contentArray. That will then get returned to the insetTopShelfItems and used for the top shelf.
            contentItem.title = dataItem.title
            contentItem.displayURL = dataItem.displayURL
            // contentItem.imageURL = dataItem.imageUrl
            contentItem.setImageURL(dataItem.imageUrl, forTraits: .screenScale1x)
            contentItem.imageShape = .poster
            
            return contentItem
        }//end map
        
        comedyMoviesSection.topShelfItems =  comedyMoviesArray
        
        // return all sections
        return [horrorMoviesSection, actionMoviesSection, comedyMoviesSection]
    }
    
    //--3 NOTE WHEN RUNNING: When you start this app up you'll just see a blank screen, this is because the app is running but we didn't do anything in the actual app, just for the top shelf. Hit cmd + shift + H to exit the app and return to the home screen. Then hit cmd + shift + R to display the simulated TV remote. After that you can use the keyboard arrow keys and enter to navigate the UI.
    
    
}

