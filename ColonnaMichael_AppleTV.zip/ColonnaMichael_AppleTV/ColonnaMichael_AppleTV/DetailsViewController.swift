//
//  DetailsViewController.swift
//  ColonnaMichael_AppleTV
//
//  Created by Michael Colonna on 12/9/17.
//  Copyright © 2017 ColonnaJr. All rights reserved.
//

import UIKit

class DetailsViewController: UIViewController {
    
    var movieTitle: String?
    var movieDescription: String?
    var movieRating: String?
    
    var movieImageString: String?
    
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var ratingLabel: UILabel!
    
    @IBOutlet weak var descriptionLabel: UITextView!
    
    @IBOutlet weak var movieImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        titleLabel.text = movieTitle
        ratingLabel.text = movieRating
        descriptionLabel.text = movieDescription
        movieImage.image = UIImage(named:movieImageString ?? "")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func backButton(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
}
