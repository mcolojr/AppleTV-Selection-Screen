//
//  ViewController.swift
//  ColonnaMichael_AppleTV
//
//  Created by Michael Colonna on 12/8/17.
//  Copyright © 2017 ColonnaJr. All rights reserved.
//


import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate { //UITableViewDataSource, UITableViewDelegate
    
    // get all movies from extension
    var movies = TVTopShelfData.sampleItems

    @IBOutlet weak var tableView: UITableView!
        
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        tableView.delegate = self
        tableView.dataSource = self
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return movies.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") as! CustomTableViewCell
        
        cell.titleLabel.text = movies[indexPath.row].title
        cell.categoryLabel.text = movies[indexPath.row].category.rawValue
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        print("Cell is selected")
    }
    
    // MARK: - Segues
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "toDetailsViewController" {
            
            let detailsView = segue.destination as! DetailsViewController
            
            // get information from the selected row
            if let indexPath = tableView.indexPathForSelectedRow {
                
                // The detail view should display the 3 display strings and the image.
                // It should also contain a back button to return the user to the table view display.
                detailsView.movieTitle = movies[indexPath.row].title
                detailsView.movieDescription = movies[indexPath.row].description
                detailsView.movieRating = movies[indexPath.row].rating
                detailsView.movieImageString = movies[indexPath.row].imageName
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

