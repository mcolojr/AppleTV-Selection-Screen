//
//  TVTopShelfData.swift
//  ColonnaMichael_AppleTV
//
//  Created by Michael Colonna on 12/8/17.
//  Copyright © 2017 ColonnaJr. All rights reserved.
//

import Foundation

//--1 For the Apple TV we'll get started here in our data provider struct. This is going to be used to define each piece of content we wish to display in the top shelf for our application. Pay close attention to the Target Membership of this file, it is part of both the TV Application (even though we're not doing any work there yet we'll build off of this for day 2 of Apple TV) and the ServiceProvide extension. Before we dive in here there are two other areas you should take a quick look at.
//  The first is in the Assets group you'll see our application icon built out. Placing your mouse pointer over top of the preview and moving it around you can see a live preview of the parallaxing effect. Now with these app icons you'll note that that have multiple layers to them but only default to 3. If you need to max of 5 just right click the icon name and choose New Apple TV Image Stack Layer. You can also remove layers, just be sure you have at least 2 as that is the minimum requirement.
//  The other is the images group that is right below this file. Primarily, note that each image is a part of both targets like this file. This is also why these images are in a group there and not in the assets folder. If they were there they would not display in the top shelf. Now on to our data struct
//  Note: You are welcome to use this data struct file for your labs related to Apple TV if you wish to do so.
struct TVTopShelfData {
    
    //The groups here will be used to define and separate the types of content for our top shelf. This makes it easy for us to separate content, especially for the segmented style of top shelf.
    enum Category:String {
        case Horror
        case Action
        case Comedy
        
        static let allCategories: [Category] = [.Horror, .Action, .Comedy]
    }
    
    //Each item will be part of one of our three defined categories
    let category: Category
    
    //Each item will need a number to identify it within the category
    let number: Int
    
    //Each item will have a title we can use for display purposes.
    let title: String
    let description: String
    let rating: String
    
    //This image name variable is constructed to exactly match the image names in the project. We need the group and number for other variables as well, hence why we are creating the image string this way instead of just providing it when we create an instance of TVTopShelfData
    var imageName: String {
        return "\(category.rawValue)\(number).jpeg"
    }
    //The identifier we'll use in the top shelf system. Each item past present and future must have a unique id for the OS to use for top shelf display.
    var identifier: String {
        return "\(category.rawValue)\(number)"
    }
    
    //Create a URL path for the system to use for display purposes
    var displayURL: URL {
        var components = URLComponents()
        components.scheme = "uikitcatalog"
        components.path = "tvTopShelfItem"
        components.queryItems = [URLQueryItem(name: "identifier", value: identifier)]
        
        return components.url!
    }
    
    //Create an image URL so that the top shelf can find our images in the file system of the OS as the top shelf runs when our app is asleep
    var imageUrl: URL {
        let mainBundle = Bundle.main
        guard let imageUrl = mainBundle.url(forResource: imageName, withExtension: nil) else {
            fatalError("Error getting local image URL")
        }
        return imageUrl
    }
}

//This extension is used to construct all of our TVTopShelfData items and create some data sets for use later in either our top shelf or the app

extension TVTopShelfData {
    //All of the data items
    static var sampleItems: [TVTopShelfData] = {
        return[TVTopShelfData(category: .Horror, number: 1, title: "Scary Movie", description: "Defying the very notion of good taste, Scary Movie out-parodies the pop culture parodies with a no-holds barred assault on the most popular images and talked-about moments from recent films, television and commercials. The film boldly fires barbs at the classic scenes from Scream, The Sixth Sense, The Matrix, I Know What You Did Last Summer and The Blair Witch Project, then goes on to mock a whole myriad of teen movie clichés, no matter the genre.", rating: "R"),
               TVTopShelfData(category: .Horror, number: 2, title: "It", description: "Seven young outcasts in Derry, Maine, are about to face their worst nightmare -- an ancient, shape-shifting evil that emerges from the sewer every 27 years to prey on the town's children. Banding together over the course of one horrifying summer, the friends must overcome their own personal fears to battle the murderous, bloodthirsty clown known as Pennywise.", rating: "R"),
               TVTopShelfData(category: .Horror, number: 3, title: "It Follows", description: "After carefree teenager Jay (Maika Monroe) sleeps with her new boyfriend, Hugh (Jake Weary), for the first time, she learns that she is the latest recipient of a fatal curse that is passed from victim to victim via sexual intercourse. Death, Jay learns, will creep inexorably toward her as either a friend or a stranger. Jay's friends don't believe her seemingly paranoid ravings, until they too begin to see the phantom assassins and band together to help her flee or defend herself.", rating: "R"),
               TVTopShelfData(category: .Horror, number: 4, title: "The Babadook", description: "A troubled widow (Essie Davis) discovers that her son is telling the truth about a monster that entered their home through the pages of a children's book.", rating: "R"),
               TVTopShelfData(category: .Horror, number: 5, title: "The Shining", description: "Jack Torrance (Jack Nicholson) becomes winter caretaker at the isolated Overlook Hotel in Colorado, hoping to cure his writer's block. He settles in along with his wife, Wendy (Shelley Duvall), and his son, Danny (Danny Lloyd), who is plagued by psychic premonitions. As Jack's writing goes nowhere and Danny's visions become more disturbing, Jack discovers the hotel's dark secrets and begins to unravel into a homicidal maniac hell-bent on terrorizing his family.", rating: "R"),
               
               TVTopShelfData(category: .Action, number: 1, title: "Die Hard", description: "New York City policeman John McClane (Bruce Willis) is visiting his estranged wife (Bonnie Bedelia) and two daughters on Christmas Eve. He joins her at a holiday party in the headquarters of the Japanese-owned business she works for. But the festivities are interrupted by a group of terrorists who take over the exclusive high-rise, and everyone in it. Very soon McClane realizes that there's no one to save the hostages -- but him.", rating: "R"),
               TVTopShelfData(category: .Action, number: 2, title: "The Dark Knight", description: "With the help of allies Lt. Jim Gordon (Gary Oldman) and DA Harvey Dent (Aaron Eckhart), Batman (Christian Bale) has been able to keep a tight lid on crime in Gotham City. But when a vile young criminal calling himself the Joker (Heath Ledger) suddenly throws the town into chaos, the caped Crusader begins to tread a fine line between heroism and vigilantism.", rating: "PG-13"),
               TVTopShelfData(category: .Action, number: 3, title: "Predator", description: "Dutch (Arnold Schwarzenegger), a soldier of fortune, is hired by the U.S. government to secretly rescue a group of politicians trapped in Guatemala. But when Dutch and his team, which includes weapons expert Blain (Jesse Ventura) and CIA agent George (Carl Weathers), land in Central America, something is gravely wrong. After finding a string of dead bodies, the crew discovers they are being hunted by a brutal creature with superhuman strength and the ability to disappear into its surroundings.", rating: "R"),
               TVTopShelfData(category: .Action, number: 4, title: "The Avengers", description: "When Thor's evil brother, Loki (Tom Hiddleston), gains access to the unlimited power of the energy cube called the Tesseract, Nick Fury (Samuel L. Jackson), director of S.H.I.E.L.D., initiates a superhero recruitment effort to defeat the unprecedented threat to Earth. Joining Fury's 'dream team' are Iron Man (Robert Downey Jr.), Captain America (Chris Evans), the Hulk (Mark Ruffalo), Thor (Chris Hemsworth), the Black Widow (Scarlett Johansson) and Hawkeye (Jeremy Renner).", rating: "PG-13"),
               TVTopShelfData(category: .Action, number: 5, title: "Terminator 2: Judgment Day", description: "In this sequel set eleven years after 'The Terminator,' young John Connor (Edward Furlong), the key to civilization's victory over a future robot uprising, is the target of the shape-shifting T-1000 (Robert Patrick), a Terminator sent from the future to kill him. Another Terminator, the revamped T-800 (Arnold Schwarzenegger), has been sent back to protect the boy. As John and his mother (Linda Hamilton) go on the run with the T-800, the boy forms an unexpected bond with the robot.", rating: "R"),
               
               TVTopShelfData(category: .Comedy, number: 1, title: "Superbad", description: "High-school seniors Seth (Jonah Hill) and Evan (Michael Cera) have high hopes for a graduation party: The co-dependent teens plan to score booze and babes so they can become part of the in-crowd, but separation anxiety and two bored police officers (Bill Hader, Seth Rogen) complicate the pair's self-proclaimed mission.", rating: "R"),
               TVTopShelfData(category: .Comedy, number: 2, title: "Airplane!", description: "This spoof comedy takes shots at the slew of disaster movies that were released in the 70s. When the passengers and crew of a jet are incapacitated due to food poisoning, a rogue pilot with a drinking problem must cooperate with his ex-girlfriend turned stewardess to bring the plane to a safe landing.", rating: "PG"),
               TVTopShelfData(category: .Comedy, number: 3, title: "Anchorman: The Legend of Ron Burgundy", description: "Hotshot television anchorman Ron Burgundy (Will Ferrell) welcomes upstart reporter Veronica Corningstone (Christina Applegate) into the male-dominated world of 1970s broadcast news -- that is, until the talented female journalist begins to outshine Burgundy on air. Soon he grows jealous, begins a bitter feud with Veronica and eventually makes a vulgar slip on live TV that ruins his career. However, when an outrageous story breaks at the San Diego Zoo, Ron may get a chance to redeem himself.", rating: "PG-13"),
               TVTopShelfData(category: .Comedy, number: 4, title: "Shaun of the Dead", description: "Shaun (Simon Pegg) is a 30-something loser with a dull, easy existence. When he's not working at the electronics store, he lives with his slovenly best friend, Ed (Nick Frost), in a small flat on the outskirts of London. The only unpredictable element in his life is his girlfriend, Liz (Kate Ashfield), who wishes desperately for Shaun to grow up and be a man. When the town is inexplicably overrun with zombies, Shaun must rise to the occasion and protect both Liz and his mother (Penelope Wilton).", rating: "R"),
               TVTopShelfData(category: .Comedy, number: 5, title: "Hot Fuzz", description: "As a former London constable, Nicholas Angel (Simon Pegg) finds it difficult to adapt to his new assignment in the sleepy British village of Sandford. Not only does he miss the excitement of the big city, but he also has a well-meaning oaf (Nick Frost) for a partner. However, when a series of grisly accidents rocks Sandford, Nick smells something rotten in the idyllic village.", rating: "R"),
               
               ]
    }()
    
    //Create an array for displaying horror section of sectioned top shelf.
    static var section1ItemsForSectionTopShelf: [TVTopShelfData] = {
        //Filter our main data set by the Pillars group. Try changing this to the rocks group to see different results on the top shelf.
        let horrorItems = TVTopShelfData.sampleItems.filter {$0.category == .Horror}
        //Return an array using the prefix method. This means that however many items for the number we pass in, starting at the front of the array, are put in a new array and passed back. It's redundant in this case as we only have 3 total but if you had 100 it wouldn't make sense to put all of them in the top shelf since the user won't want to scroll through 100 items before even getting into the app.
        return Array(horrorItems.prefix(2))
    }()
    
    
    //Create an array for displaying action section of sectioned top shelf.
    static var section2ItemsForSectionTopShelf: [TVTopShelfData] = {
        //Filter our main data set by the Pillars group. Try changing this to the rocks group to see different results on the top shelf.
        let actionItems = TVTopShelfData.sampleItems.filter {$0.category == .Action}
        //Return an array using the prefix method. This means that however many items for the number we pass in, starting at the front of the array, are put in a new array and passed back. It's redundant in this case as we only have 3 total but if you had 100 it wouldn't make sense to put all of them in the top shelf since the user won't want to scroll through 100 items before even getting into the app.
        return Array(actionItems.prefix(2))
    }()
    
    
    //Create an array for displaying comedy section of sectioned top shelf.
    static var section3ItemsForSectionTopShelf: [TVTopShelfData] = {
        //Filter our main data set by the Pillars group. Try changing this to the rocks group to see different results on the top shelf.
        let comedyItems = TVTopShelfData.sampleItems.filter {$0.category == .Comedy}
        //Return an array using the prefix method. This means that however many items for the number we pass in, starting at the front of the array, are put in a new array and passed back. It's redundant in this case as we only have 3 total but if you had 100 it wouldn't make sense to put all of them in the top shelf since the user won't want to scroll through 100 items before even getting into the app.
        return Array(comedyItems.prefix(2))
    }()
}
